# Чтение данных из файла и формирование списка сложных ремонтов
def read_repairs(file_name):
    with open(file_name, 'r', encoding='utf-8') as file:
        next(file)  # Пропускаем заголовок
        return [line.strip().split('\t') for line in file if line.strip().split('\t')[-1] == 'Сложный']

# Запись отсортированных данных в файл
def write_sorted_repairs(repairs, file_name):
    with open(file_name, 'w', encoding='utf-8') as file:
        file.write("Дата обращения\tНазвание\tПроизводитель\tКатегория\n")
        file.write('\n'.join(['\t'.join(repair) for repair in sorted(repairs, key=lambda x: x[2])]))

# Основная программа
input_file = 'in.txt'
output_file = 'out.txt'

repairs = read_repairs(input_file)
write_sorted_repairs(repairs, output_file)

print("Готово. Результат записан в out.txt.")


#