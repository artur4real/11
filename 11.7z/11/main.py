class RepairDatabase:
    def __init__(self, input_file, output_file):
        self.input_file = input_file
        self.output_file = output_file
        self.repairs = []

    def load_repairs(self):
        with open(self.input_file, 'r', encoding='utf-8') as file:
            next(file)  # Пропускаем заголовок
            self.repairs = [line.strip().split('\t') for line in file if line.strip()]

    def save_repairs(self):
        with open(self.output_file, 'w', encoding='utf-8') as file:
            file.write("Дата обращения\tНазвание\tПроизводитель\tКатегория\n")
            for repair in self.repairs:
                file.write('\t'.join(repair) + '\n')

    def display_menu(self):
        menu = """
        Меню:
        1. Вывести все ремонты
        2. Добавить ремонт
        3. Удалить ремонт
        4. Редактировать ремонт
        5. Выход
        """

        while True:
            print(menu)
            choice = input("Выберите действие: ")

            if choice == '1':
                self.display_repairs()
            elif choice == '2':
                self.add_new_repair()
            elif choice == '3':
                self.delete_existing_repair()
            elif choice == '4':
                self.edit_existing_repair()
            elif choice == '5':
                self.save_repairs()
                print("Данные сохранены. Выход.")
                break
            else:
                print("Некорректный ввод. Попробуйте снова.")

    def display_repairs(self):
        if self.repairs:
            for repair in self.repairs:
                print("\t".join(repair))
        else:
            print("База данных пуста.")

    def add_new_repair(self):
        date = input("Введите дату обращения: ")
        client = input("Введите имя клиента: ")
        product = input("Введите название продукта: ")
        manufacturer = input("Введите производителя: ")
        category = input("Введите категорию: ")
        self.repairs.append([date, client, product, manufacturer, category])
        print("Ремонт добавлен.")

    def delete_existing_repair(self):
        self.display_repairs()
        if self.repairs:
            index = int(input("Введите номер ремонта для удаления: "))
            if 0 <= index < len(self.repairs):
                del self.repairs[index]
                print("Ремонт удален.")
            else:
                print("Некорректный номер ремонта.")
        else:
            print("База данных пуста.")

    def edit_existing_repair(self):
        self.display_repairs()
        if self.repairs:
            index = int(input("Введите номер ремонта для редактирования: "))
            if 0 <= index < len(self.repairs):
                repair = self.repairs[index]
                new_repair = [input(f"Введите новое значение для {field}: ") for field in repair]
                self.repairs[index] = new_repair
                print("Ремонт отредактирован.")
            else:
                print("Некорректный номер ремонта.")
        else:
            print("База данных пуста.")

# Основная программа
if __name__ == "__main__":
    db = RepairDatabase("in.txt", "out.txt")
    db.load_repairs()
    db.display_menu()
